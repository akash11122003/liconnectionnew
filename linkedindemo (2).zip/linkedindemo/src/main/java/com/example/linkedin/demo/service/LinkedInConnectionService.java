package com.example.linkedin.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.example.linkedin.demo.model.LinkedInConnection;
import com.example.linkedin.demo.model.Person;
import com.example.linkedin.demo.repo.LinkedInConnectionRepository;
import com.example.linkedin.demo.repo.PersonRepository;

import jakarta.transaction.Transactional;

@Service
public class LinkedInConnectionService {
@Autowired
LinkedInConnectionRepository lirep;
@Autowired
PersonRepository prep;

public List<LinkedInConnection> getAllLinkedInConnection()
{
	List<LinkedInConnection> liList=lirep.findAll();
	return liList;
}
public LinkedInConnection saveConnection(LinkedInConnection c)
{
	return lirep.save(c);
}

public LinkedInConnection updateConnection(LinkedInConnection c,String username)
{
	Optional<LinkedInConnection> lidata=lirep.findById(username);
	if(lidata.isPresent())
	
	{
		return lirep.save(c);
	}
	return null;
}

public void deleteConnection(String username) 
{
	lirep.deleteById(username);
	
}

public LinkedInConnection getByIdConnection(String s)
{
	LinkedInConnection liData = lirep.findById(s).get();
	return liData;
}

public List<LinkedInConnection> sortConnection(String field){
	return lirep.findAll(Sort.by(field));
}

public List<LinkedInConnection> pagingli(int offset,int noofrecords)
{
	Pageable paging=PageRequest.of(offset, noofrecords);
	Page<LinkedInConnection> licontent=lirep.findAll(paging);
	return licontent.getContent();
}


public List<LinkedInConnection> pagingAndSortingConnection(int offset,
int pageSize,String field) {
Pageable paging = PageRequest.of(offset, pageSize).withSort(Sort.by(field));
Page<LinkedInConnection> stud=lirep.findAll(paging);
return stud.getContent();
}

public List<LinkedInConnection> fetchConnectionsByNamePrefix(String prefix)
{
	return lirep.findByNameStartingWith(prefix);
}

public List<LinkedInConnection> fetchConnectionsByPassyear(int year)
{
	return lirep.findByPassyear(year);
}


public List<LinkedInConnection> getDataByName(String name, String department) {
	return lirep.getlname(name, department);
}
public List<LinkedInConnection> getDataByImpre(String name, float impression) {
	return lirep.getlimpre(name,impression);
}

@Transactional
public int deleteStudentByName(String name)
{
	return lirep.deleteLinkedInConnection(name);
}

@Transactional
public int updateStudentBy(String premium, int followers , String username) 
{
	return lirep.updateLinkedInConnection(premium,followers,username);
}


public List<Person> getPerson() {
	return prep.findAll();
}
}