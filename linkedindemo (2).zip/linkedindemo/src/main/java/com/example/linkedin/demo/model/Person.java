package com.example.linkedin.demo.model;

import java.util.List;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;

@Entity
public class Person {
	
	@Id
	private String deptname;
	private String instagram_id;
	private String posts;
	
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="user_name")
	private LinkedInConnection insta;
	
	
	@OneToMany(cascade = CascadeType.ALL)
	@JoinColumn(name="department")
	private List<LinkedInConnection> department;
	
	
	public String getDeptname() 
	{
		return deptname;
	}
	public void setDeptname(String deptname) 
	{
		this.deptname = deptname;
	}
	public List<LinkedInConnection> getDepartment() 
	{
		return department;
	}
	public void setDepartment(List<LinkedInConnection> department) 
	{
		this.department = department;
	}
	public String getInstagram_id() 
	{
		return instagram_id;
	}
	public void setInstagram_id(String instagram_id) 
	{
		this.instagram_id = instagram_id;
	}
	public String getPosts() {
		return posts;
	}
	public void setPosts(String posts) 
	{
		this.posts = posts;
	}
	public LinkedInConnection getInsta() 
	{
		return insta;
	}
	public void setInsta(LinkedInConnection insta) 
	{
		this.insta = insta;
	}
	
	
}
