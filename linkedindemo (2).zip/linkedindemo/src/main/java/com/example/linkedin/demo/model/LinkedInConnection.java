package com.example.linkedin.demo.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;


@Entity
public class LinkedInConnection {
	@Id
	private String username;
	private String name;
	private String email;
	private int connections;
	private long followers;
	private float impression;
	private String premium;
	private int passyear;
	private int posts;
	
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getConnections() {
		return connections;
	}
	public void setConnections(int connections) {
		this.connections = connections;
	}
	public long getFollowers() {
		return followers;
	}
	public void setFollowers(long followers) {
		this.followers = followers;
	}
	public float getImpression() {
		return impression;
	}
	public void setImpression(float impression) {
		this.impression = impression;
	}
	public String getPremium() {
		return premium;
	}
	public void setPremium(String premium) {
		this.premium = premium;
	}
	public int getPassyear() {
		return passyear;
	}
	public void setPassyear(int passyear) {
		this.passyear = passyear;
	}
	public int getPosts() {
		return posts;
	}
	public void setPosts(int posts) {
		this.posts = posts;
	}
	
	}
	