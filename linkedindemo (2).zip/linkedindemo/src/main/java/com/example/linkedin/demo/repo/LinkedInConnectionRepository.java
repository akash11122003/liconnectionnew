package com.example.linkedin.demo.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import com.example.linkedin.demo.model.LinkedInConnection;

public interface LinkedInConnectionRepository extends JpaRepository<LinkedInConnection, String>{
	
	//positionalParameter
	@Query("select l from LinkedInConnection l where l.name=?1")
	List<LinkedInConnection> getlname(String name,String department );
	
	//nameParameter
	@Query("select l from LinkedInConnection l where l.name=:names and l.impression=:impressions")
	List<LinkedInConnection> getlimpre(String names,float impressions);
	
	
	@Modifying
	@Query("delete from LinkedInConnection c where c.name=?1")
	public int deleteLinkedInConnection(String name);
		
	@Modifying
	@Query("update LinkedInConnection c set c.premium=?1,c.followers=?2 where c.username=?3")
	public int updateLinkedInConnection(String premium,int followers,String username);
	
	
	
	List<LinkedInConnection> findByNameStartingWith(String name);
	List<LinkedInConnection> findByPassyear(int year);
//	List<LinkedInConnection> findByDepartment(String department);
}
