package com.example.linkedin.demo.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.linkedin.demo.model.Person;

public interface PersonRepository extends JpaRepository<Person,String> {

}
