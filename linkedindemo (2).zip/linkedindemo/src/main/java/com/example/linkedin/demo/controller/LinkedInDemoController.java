package com.example.linkedin.demo.controller;

import java.util.List;
import org.springframework.http.HttpStatus;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.example.linkedin.demo.model.LinkedInConnection;
import com.example.linkedin.demo.model.Person;
import com.example.linkedin.demo.service.LinkedInConnectionService;


import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;


@RestController
public class LinkedInDemoController {
@Autowired
	LinkedInConnectionService liSer;


	
	@GetMapping(value="/fetchConn")
	public List<LinkedInConnection> getAllLinkedInConnection()
	{
		
	List<LinkedInConnection> liList=liSer.getAllLinkedInConnection();
	return liList;
}
	@PostMapping(value="/insertConn")
	public LinkedInConnection saveConnection(@RequestBody LinkedInConnection c) {
		
		return liSer.saveConnection(c);
	}
	@PutMapping(value="/updateConn/{uname}")
	
	public LinkedInConnection updateConnection(@RequestBody LinkedInConnection c,@PathVariable("uname") String username)
	{
		return liSer.updateConnection(c,username);
	}
	
	
	@DeleteMapping(value="/deleteConn/{uname}")
	public String  deleteconnection(@PathVariable("uname") String username)
	{
		liSer.deleteConnection(username);
		return "Deleted";
	}
	
	@GetMapping(value="/getConn/{rno}")
	public LinkedInConnection getStudent(@PathVariable("rno")  String s)
	{
		return liSer.getByIdConnection(s);
	}
	
	@GetMapping("/sortConn/{field}")
	public List<LinkedInConnection> sortConnection(@PathVariable String field)
	{
		return liSer.sortConnection(field);
	}	
	
	
	@GetMapping("/pageData/{offset}/{noofrecords}")
		public List<LinkedInConnection> pagingli(@PathVariable("offset") int offset,@PathVariable("noofrecords") int noofRecords)
		{
		return liSer.pagingli(offset, noofRecords);
		}
	
	@GetMapping("/pagingAndSortingConn/{offset}/{numbofrecords}/{field}")
	public List<LinkedInConnection> pagingAndSortingConnection(@PathVariable int offset,@PathVariable int pageSize,@PathVariable String field)
	{
	return liSer.pagingAndSortingConnection(offset, pageSize, field);
	}
	
@Operation(summary = "Get the data by starting name")
@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "successful"),
		@ApiResponse(responseCode = "401", description = "Invalid credentials"),
		@ApiResponse(responseCode = "404", description = "Path not found") })
@ResponseStatus(HttpStatus.CREATED)
	@GetMapping("/fetchStudentsByNamePrefix")
	public List<LinkedInConnection> fetchConnectionsByNamePrefix(@RequestParam String prefix)
	{
		return liSer.fetchConnectionsByNamePrefix(prefix);
	}
	
@Operation(summary = "Get the LinkedIn connection by passyear")
@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "successful"),
		@ApiResponse(responseCode = "401", description = "Invalid credentials"),
		@ApiResponse(responseCode = "404", description = "Path not found") })
@ResponseStatus(HttpStatus.CREATED)

	@GetMapping("/fetchStudentsByPassYear")
	public List<LinkedInConnection> fetchConnectionsByPassyear(@RequestParam int year)
	{
		return liSer.fetchConnectionsByPassyear(year);
	}
	
@Operation(summary = "Get by name and department")
@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "successful"),
		@ApiResponse(responseCode = "401", description = "Invalid credentials"),
		@ApiResponse(responseCode = "404", description = "Path not found") })
@ResponseStatus(HttpStatus.CREATED)

	@GetMapping("/queryDataName")
	public List<LinkedInConnection> getDataByName(@RequestParam String name,@RequestParam String department)
	{
		return liSer.getDataByName(name,department);
	}
	
@Operation(summary = "Get by impression and name")
@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "successful"),
		@ApiResponse(responseCode = "401", description = "Invalid credentials"),
		@ApiResponse(responseCode = "404", description = "Path not found") })
@ResponseStatus(HttpStatus.CREATED)

	@GetMapping("/queryDataImpre")
	public List<LinkedInConnection> getDataByImper(@RequestParam String name,@RequestParam float impression)
	{
		return liSer.getDataByImpre(name,impression);
	}
	
@Operation(summary = "Delete using name")
@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "successful"),
		@ApiResponse(responseCode = "401", description = "Invalid credentials"),
		@ApiResponse(responseCode = "404", description = "Path not found") })
@ResponseStatus(HttpStatus.CREATED)

	@DeleteMapping("/deleteStudentByName")
	public String deleteStudentByName(@RequestParam String name)
	{
	int result=liSer.deleteStudentByName(name)	;
	
	if(result >0)
	return "Student record deleted";
	else
	return "Problem occured while deleting";
	}
	

@Operation(summary = "To Update premium")
@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "successful"),
		@ApiResponse(responseCode = "401", description = "Invalid credentials"),
		@ApiResponse(responseCode = "404", description = "Path not found") })
@ResponseStatus(HttpStatus.CREATED)
@PutMapping("/updateStudentBy")
public int updateStudentBy(@RequestParam String premium ,@RequestParam int followers,@RequestParam String username)
{
	return liSer.updateStudentBy(premium,followers,username);
}


@Operation(summary = "Get data of child entity")
@ApiResponses(value = { @ApiResponse(responseCode = "200", description = "successful"),
		@ApiResponse(responseCode = "401", description = "Invalid credentials"),
		@ApiResponse(responseCode = "404", description = "Path not found") })
@ResponseStatus(HttpStatus.CREATED)

	@GetMapping("/fetchperson")
	public List<Person> getPerson()
	{
	List<Person> liList=liSer.getPerson();
	return liList;
}
	
	





}